title: “家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装
date: '2020-01-29 17:14:57'
updated: '2020-02-05 20:23:17'
tags: [PVE, 虚拟机]
permalink: /articles/2020/01/29/1580289297380.html
---
当前随着各种云盘、网盘的限速和退出市场，家庭云存储再次作为热点出现在大家的视线。那么为了建立家庭云中心，你可以直接选择一套成熟的整机 NAS 方案，但是作为一个喜欢折腾的人来说，自己搞一套完全定制的方案，这样就既可以享受组装和折腾的乐趣，同时也可以以此作为一个不断学习的过程。

那么在建设整个项目之前，我们先来看下项目的网络拓扑图：

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/154d781b83864cdd8abc5634a48c3bd1)

作为整个系统的底层宿主机，我们可以选择 PVE，也可以选择 ESXI，而经过比较，我最后选择了 PVE 作为我整个系统的底层宿主机，其他各个系统都是已虚拟机的方式存在于 PVE 上。

> Proxmox VE is a complete open-source platform for all-inclusive enterprise virtualization that tightly integrates KVM hypervisor and LXC containers, software-defined storage and networking functionality on a single platform, and easily manages high availability clusters and disaster recovery tools with the built-in Web management interface.
>
> Proxmox VE (Proxmox Virtual Environment) 有方便易用的 Web 界面，基于 Java 的 UI 和内核接口，可以登录到 VM 客户方便的操作，还有易用的模板功能，基本跟商业 VPS 环境差不多了，支持 VT 和 ISCSI。
>
> 官网： https://www.proxmox.com/en/

那么今天我们的第一篇文章就来介绍一下如何安装 PVE ，以及其中有哪些需要注意的问题。

1. 官网下载安装包， 你将得到一个 iso 安装文件。
2. 利用官网建议的工具 https://www.balena.io/etcher/， 或其他的写盘工具将 ISO 文件写入 U 盘。
3. 将 U 盘插入 NAS 主机，开机进入 BIOS，然后选择对应的 U 盘启动。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/37567f1a3a1541128785449c04949ca7)

4. 安装界面选择 Install Proxmox VE。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p1.pstatp.com/large/pgc-image/5b331d1659b14db594b2ab7790aa992f)

5. 选择安装的磁盘，点击 option 可以选择磁盘的文件格式，最新的 PVE 6.0 支持 root ZFS 文件系统，当然你也可以选择默认的常用文件系统 EXT4。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p1.pstatp.com/large/pgc-image/72c70b47d1214782af2c6374520873c5)

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p1.pstatp.com/large/pgc-image/269937eeb0854127bcd582ce744b30af)

6. 国家输入 China，时区 shanghai。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/50748791940747ce8b2279a1fbaf7224)

7. 设置你的管理员密码和邮箱。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p9.pstatp.com/large/pgc-image/c4680759a78e4d3eab2a380021cf2398)

8. 此处需要输入你的网络配置。若有多块儿网卡，第一项请选择正确的网卡。

> 请提前规划你的网口使用，以及 IP 地址分配。我的规划方案供参考：
>
> 1、整个局域网使用 192.168.100.* 网段
>
> 2、192.168.100.1 分配给后续要装的软路由 openWRT
>
> 3、主板自带的网口划给 wan 口
>
> 4、双口网卡的网口 1 规划给 lan1 接 PC
>
> 5、双口网卡的网口 2 规划给 lan2 接 无线路由

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/4a84e9ddcd5248f6b60903b4c11ed7d3)

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/f0a665869d214715aa330fc44d28d65e)

9. 确认上面的设置没有问题，即可进入下一步，开始安装。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p1.pstatp.com/large/pgc-image/352bd17112e44b74bca0aed554a882cc)

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/f229569f4e03487196e2d9be70a494f6)

10、完成安装，取下 U 盘，重启。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p9.pstatp.com/large/pgc-image/f17d7bb885da4858b237998b764b4f74)

11、当你看到这个登录界面的时候，说明 PVE 已经顺利安装成功。屏幕显示的网址即为后台管理登录入口。此时你可以将接在该 NAS 设备的显示器，键鼠全部撤掉了。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p9.pstatp.com/large/pgc-image/fdbc2131d75145e5ae07376f79cf3605)

12、将接在 lan1 口的网线与另一台 PC 相连，然后设置 PC 端的网络如下：IP 地址和刚才 PVE 的 IP 处于一个网段即可。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p3.pstatp.com/large/pgc-image/81995d1e822d4a8c92c3edcaf5e7656c)

13、浏览器登录第 11 步界面显示的网址即可登录到 PVE 的管理界面。至此，PVE 安装完成。

![“家庭云中心”建设（篇一）：Proxmox VE（PVE）介绍及安装](http://p1.pstatp.com/large/pgc-image/a31d12a6833a4253b00d52db03b5e7ee)

**注意事项**：

1. 若 ISO 文件无法写入 U 盘，或 U 盘无法启动，请使用官方建议的软件重试。
2. 网卡选择界面请注意选对网卡，以及规划好 IP。
3. 若 PVE 已经安装完成，此时又需要修改 IP，请 SSH 登录主机：修改/etc/network 目录下的 interfaces 文件。（具体如何 SSH 登录，推荐使用 MobaXteam）

---
**下一篇预告：**

# “家庭云中心”建设（篇二）：openWRT 软路由介绍及安装
