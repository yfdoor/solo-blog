title: 【随笔】OpenWrt 固件编译过程：Github云编译
date: '2020-02-17 17:51:34'
updated: '2020-02-17 19:59:41'
tags: [openWRT]
permalink: /articles/2020/02/17/1581933094772.html
---
**OpenWrt 的编译可以分为两种方式：**

1. 本地的物理机/虚拟机/WSL（windows sub-linux）来执行编译工作。
2. 利用 GitHub 提供的 Action 功能，编写 continuous integration (CI) workflows 来实现在线云编译。

**前言：**

接上篇，本篇就介绍一下另外一种编译方法，利用 GitHub 的 CI 实现云编译。本篇内容需要你至少了解 GitHub，有账号，知道基本的 star， fork 等概念。

<div><blockquote>GitHub Ac­tions 是 GitHub 推出的持续集成 (Con­tin­u­ous in­te­gra­tion，简称 CI) 服务，它提供了配置非常不错的虚拟服务器环境（E5 2vCPU/7G RAM），基于它可以进行构建、测试、打包、部署项目。</blockquote></div>

**参考：**

> https://p3terx.com/archives/build-openwrt-with-github-actions.html
> https://github.com/P3TERX/Actions-OpenWrt
> https://github.com/KFERMercer/OpenWrt-CI

---
**项目地址：**

> https://github.com/yfdoor

我自己修改的项目，结合上面大神写的脚本，做了一些修改，主要是：

1. 源码采用官方 OpenWrt 和 Lean package 包的结合方式。
2. Merge-upstream.yml 用来自动由 openwrt 和 Lean 的 package 文件夹下载最新源码。
   ```
   A、默认是每天固定时间触发。
   B、默认由 https://github.com/openwrt/openwrt.git 更新源码。
   C、默认由 https://github.com/coolsnowwolf/lede/trunk/package/lean/ 抓取 package 文件夹。
   ```
3. OpenWrt-CI.yml 用来编译固件。
   ```
   A、默认是点击 “star” 触发编译。
   B、环境变量
          SSH_ACTIONS: true     --> 是否开启 SSH
          UPLOAD_BIN_IPK: true  --> 是否将 IPK 文件也打包上传
          UPLOAD_FIRMWARE: true --> 是否上传固件
   C、固件定制，请参照文件内说明
   ```

**使用说明：**

---
1. 首先请先将 openwrt fork 到你自己的仓库。
   https://github.com/openwrt/openwrt
2. 将本项目文件放在你 openwrt 项目 .github/workflows 目录下即可。点击自己的 star 就开始编译。源码每天会按照设定的时间自动更新。
