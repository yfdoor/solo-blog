title: 【随笔】WSL（Windows Subsystem for Linux）启用主机代理
date: '2020-02-09 22:05:03'
updated: '2020-03-28 21:31:56'
tags: [WSL, Linux]
permalink: /articles/2020/02/09/1581257103310.html
---
#### Proxychains

主要来解决利用 WSL 子系统编译固件需要翻墙下载的问题，利用 Proxychains 来通过主机的 SSR 来达到翻墙的目的。

**Install:**

```
sudo apt install proxychains
```

**Config:**

```
/etc/proxychains.conf

[ProxyList]
socks5 127.0.0.1 1080 # 1080 是你的本地 socks5 端口
```

**Usage:**

```
proxychains wget URL
proxychains ./scripts/feeds update -a
```
