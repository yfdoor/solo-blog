title: 【随笔】谷歌云（GCP）申请指南和搭建指北
date: '2020-04-11 16:22:30'
updated: '2020-04-15 12:16:37'
tags: [GitHub, SSR, GCP]
permalink: /articles/2020/04/11/1586593350545.html
---
## 一、注册GCP

进入"Google Cloud Platform" [https://cloud.google.com](https://cloud.google.com)，然后选择免费试用。注册的时候注意，现在国家/地区不能选择中国了，可以选择台湾或香港，地址随便写写，这里需要绑定一张信用卡。激活的时候会扣缴1美元，但认证成功后就会退还。注册成功后会得到 300美元的体验金，有效期一年。

## 二、创建实例

在左侧的菜单中找到 Computer Engine --> 虚拟机实例，通过创建实例或者单击加号来创建一个新的虚拟机。

1. 名称：随意
2. 区域/地区：建议选择台湾 asia-east1-c，或者香港/新加坡/日本的节点，对大陆更友好。不同的区域提供的机型系列会有些许差异，具体请查看：
   [https://cloud.google.com/compute/docs/regions-zones?hl=zh_CN](https://cloud.google.com/compute/docs/regions-zones?hl=zh_CN)
3. 机器系列：N1/N2/E2，具体差异请查看：
   [https://cloud.google.com/compute/docs/machine-types?hl=zh_CN](https://cloud.google.com/compute/docs/machine-types?hl=zh_CN)，若是用来学习搭建 SSR，我推荐选择 E2-->e2-micro，可兼顾性能和价格。

> **机器类型**
>
> 每个机器类型系列都包含不同的机器类型。每个系列都是针对特定工作负载类型的精选系列。Compute Engine 提供以下主要机器类型：
>
> * 通用机器类型可为多种工作负载提供最优性价比。
>   * N1 机器类型可提供多达 96 个 vCPU，并为每个 vCPU 提供最高 6.5 GB 内存，支持 Intel Sandy Bridge、Ivy Bridge、Haswell、Broadwell、Skylake 等 CPU 平台。
>   * N2 机器类型可提供多达 80 个 vCPU，并为每个 vCPU 提供最高 8 GB 内存，支持 Intel Cascade Lake CPU 平台。
>   * E2 机器类型是经过费用优化的虚拟机，可提供多达 16 个 vCPU，并为每个 vCPU 提供最高 8 GB 内存。E2 机器具有运行 Intel 或 AMD EPYC 处理器的预定义 CPU 平台。E2 虚拟机可以在 Compute Engine 上以最低价格提供各种计算资源。
> * 内存优化机器类型是处理内存密集型工作负载的理想选择，因为与其他机器类型相比，这些机器类型为每个核心提供更高的内存，可高达 12 TB。
> * 计算优化机器类型在 Compute Engine 上提供最高的单核心性能，并针对计算密集型工作负载进行了优化。计算优化机器类型提供 Intel 可扩缩处理器 (Cascade Lake) 和高达 3.8 GHz 的持续全核 Turbo 频率。
> * N1 和 E2 系列提供共享核心机器类型。这些机器类型分时共用一个物理核心。在运行小规模、非资源密集型应用时，使用共享核心机器类型是一种性价比更高的方法。
>   * N1：`f1-micro` 和 `g1-small` 共享核心机器类型最多有 1 个 vCPU 可用于短时间的爆发。
>   * E2：`e2-micro`、`e2-small` 和 `e2-medium` 共享核心机器类型有两个 vCPU 可用于短时间的爆发。

4. 启动磁盘：单击更改，可选择 Debian 或是 Ubuntu，看自己喜好。
5. 防火墙：请勾选允许HTTP流量，允许HTTPS流量

## 三、网络配置

左上角导航栏找到下列选项调整网络：

1. VPC网络 -- 外部IP地址：IP地址的类型从“临时”调整为“静态”。
2. 防火墙规则 -- 创建防火墙规则（未提及的全部默认）：流量方向 ~ 入站、目标 ~ 网络中的所有实例、来源ip地址 ~ 0.0.0.0/0、协议和端口 ~ 全部允许。
3. 防火墙规则 -- 创建防火墙规则（未提及的全部默认）：流量方向 ~ 出站、目标 ~ 网络中的所有实例、来源ip地址 ~ 0.0.0.0/0、协议和端口 ~ 全部允许。
4. 注意要创建两次防火墙规则，一次出站，一次入站。

## 四、学习配置 SSR 及 BBR

1. 虚拟机控制台：SSH 在浏览器窗口中打开。
2. 获取root权限：

   ```
   sudo su
   ```
3. 安装BBR：

   ```
   wget --no-check-certificate https://github.com/teddysun/across/raw/master/bbr.sh && chmod +x bbr.sh && ./bbr.sh
   ```
4. 安装成功后执行：

   ```
   sysctl net.ipv4.tcp_available_congestion_control
   ```
   若出现类似含有 bbr 字样即 BBR 安装成功。

   ```nginx
   net.ipv4.tcp_available_congestion_control = bbr cubic reno
   ```
5. 安装SSR（根据脚本提示来）：

   一键安装脚本：

   ```
   wget --no-check-certificate https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocksR.sh
   chmod +x shadowsocksR.sh
   ./shadowsocksR.sh 2>&1 | tee shadowsocksR.log
   ```
   或者：

   ```
   wget --no-check-certificate https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocks-all.sh
   chmod +x shadowsocks-all.sh
   ./shadowsocks-all.sh 2>&1 | tee shadowsocks-all.log
   ```
   具体差异，请参考大神 Github：[https://github.com/teddysun](https://github.com/teddysun)
6. 安装V2Ray（根据脚本提示来）：

   ```
   bash <(curl -s -L https://git.io/v2ray.sh)
   ```
