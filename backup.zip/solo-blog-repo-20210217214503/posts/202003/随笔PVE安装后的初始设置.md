title: 【随笔】PVE 安装后的初始设置
date: '2020-03-28 19:32:51'
updated: '2020-03-28 21:39:17'
tags: [PVE]
permalink: /articles/2020/03/28/1585395171185.html
---
* 更换 Debian 源：
  ```
  cp /etc/apt/sources.list /etc/apt/sources.list.BK
  cat > /etc/apt/sources.list << EOF
  # 默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释

  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-updates main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-updates main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-backports main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-backports main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian-security buster/updates main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian-security buster/updates main contrib non-free

  EOF
  ```
* 定义 pve-no-subscription：
  ```
  sed -i 's/deb https/# deb https/g' /etc/apt/sources.list.d/pve-enterprise.list
  echo 'deb https://mirrors.tuna.tsinghua.edu.cn/proxmox/debian buster pve-no-subscription' > /etc/apt/sources.list.d/pve-no-subscription.list
  ```
* 去订阅弹窗：
  ```
  cp /usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js /usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js.BK
  sed -i "s/data.status !== 'Active'/false/g" /usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js
  ```
