title: “家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装
date: '2020-01-29 17:18:55'
updated: '2020-02-05 20:27:12'
tags: [Transmission, 下载]
permalink: /articles/2020/01/29/1580289535002.html
---
家庭云中心的建设，除了搭建好 NAS 平台，其配套的各种软件自然也不能少。今天我们就介绍一下下载工具 Transmission 的安装以及汉化。

> Transmission 全称 TransmissionBittorrent，由 C 开发而成（Mac OS 上用的是 Objective-C），硬件资源消耗极少，界面极度精简。支持包括 Linux、BSD、Solaris、Mac OS X 等多种操作系统，以及 Networked Media Tank、WD MyBook、ReadyNAS、D-Link DNS-323 & CH3SNAS、Synology 等多种设备。支持 GTK+、命令行、Web 等多种界面。
>
> 官网：https://www.transmissionbt.com

下面我们就开始今天的分享：

1. 这个软件我们不需要下载，因为 OMV 的插件里已经集成了，所以我们可以直接通过 OMV 来安装。
2. OMV 默认插件库不包含该插件，所以首先我们要安装一个扩展插件库 OMV-EXTRAS，该库可以在 http://omv-extras.org/joomla/index.php/guides 找到，下载最新的 OMV 4.0 对应的 openmediavault-omvextrasorg_latest_all4.deb
3. 登录 OMV 的管理界面，登录后请在左侧的菜单栏找到 “插件”，选择上传，将刚才下载的包上传上去，上传完成后，刷新找到下面的这个插件，然后安装。安装成功后就会在左侧菜单栏“插件”下面多出一个 “OMV-Extras”的选项。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p3.pstatp.com/large/pgc-image/b6a885111136432783012148a06f1156)

4. 在“插件”中查找 “Transmission”，找到直接勾选，然后安装。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p9.pstatp.com/large/pgc-image/91df0d2ed434427894450cfa1f4a703f)

5. 安装成功后你就可以在左侧菜单栏“服务”中看到一个“BitTorrent 下载”的项目。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p3.pstatp.com/large/pgc-image/e2043935044e4fa7b5cbe803f8b42f93)

6. 此时我们需要做一些必要的设置，下载才能正式启动。其中的大部分可以默认或是按照你的需求来设置，但下面这几项一定要设置好：“设置”--> 启动； “File and location”--> 下载里指定下载的文件夹；“RPC”--> 启动并设置好用户名密码。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p3.pstatp.com/large/pgc-image/ec905792530e49f99ad35d5d65518319)

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p1.pstatp.com/large/pgc-image/da7c6ae616c348a595ff620020765734)

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p1.pstatp.com/large/pgc-image/2a7b103e30d3495392abfcde5b4eecfa)

7. 上面的设置应用后，就可以从 Web 页面登录了 http://x.x.x.x:9091， 前面的 IP 是你 OMV 的 IP 地址。输入刚才用户名和密码。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p3.pstatp.com/large/pgc-image/65f2002c5db24407bc8504f2b94e0db3)

8. 此时你发现界面为英文的，那我们再来做个汉化。这里我们就要感谢 GitHub 上的托管”transmission-web-control“这个脚本的作者了。
   项目网址：https://github.com/ronggang/transmission-web-control
   安装帮助：https://github.com/ronggang/transmission-web-control/wiki/Linux-Installation-CN
9. 安装完成后，再打开界面就是熟悉的中文了。

![“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装](http://p3.pstatp.com/large/pgc-image/cfa536bd18b946b882b02c660e2ace5f)

10、至此，我们的 transmission 就全部安装完成了。你就可以开始开心的下下下了。。。快把你的硬盘塞满吧。

**注意事项：**

1. transmission 中选择的下载文件夹 transmission 用户需要有可读写的权限。否则无法下载。
2. 若下载 PT 请将设置中的 LPD 关掉。
3. 每次 OMV 的设置改动，除了保存，记得还要点击应用才能生效。

---
**下一篇预告：**

# **“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装**
