title: “家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装
date: '2020-01-29 17:18:15'
updated: '2020-02-05 20:23:46'
tags: [OMV, NAS]
permalink: /articles/2020/01/29/1580289494989.html
---
我们装好了底层宿主 PVE，然后又装好软路由 openWRT，现在已经可以自由自在的上网畅游了。但是请不要忘了我们的主题：“家庭云中心”，万里长征才开始第一步，那么现在就开始有请我们的主角登场了。

作为 NAS 市场上常用的系统自然是非“群晖”莫属，但是作为 NAS 系统，其实还有很多选择其他选择，例如：

1. FreeNAS，目前最受欢迎的开源免费 NAS 操作系统之一，基于以安全和稳定著称的 FreeBSD 系统开发，由 ixsystems 公司的技术团队维护。
2. NAS4Free，基于 FreeNAS 0.7 开发的一个分支，由原 FreeNAS 系统开发者发起创建。许多恋旧的朋友忠实的跟随，安装要求没有 FreeNAS 高，版本更新也很及时。
3. OpenMediaVault，由原 FreeNAS 核心开发成员 Volker Theile 发起的基于 Debian Linux 的开源 NAS 操作系统，主要面向家庭用户和小型办公环境，最近发布了针对树莓派的安装包，值得关注。
   官网：https://www.openmediavault.org

经过比较，我最后选择了 openmediavault （OMV），主要是这个系统相对另外两个系统来说对硬件要求较低，更适合家用，而且国内访问速度相对较快。

而对于黑群晖的话，第一毕竟是“黑”的，第二群晖的磁盘管理会在每块磁盘中写入一部分系统文件（BASIC 模式下大概是每块盘都占用 4.6G 左右），和我想要的系统就是系统盘，存储就是存储盘的需求有些不符。

那么接下来我们就开始我们的 OMV 之旅：

1. 首先请在 OMV 官网下载最新的安装文件， 你会得到一个 ISO 文件。然后请在 PVE 的 “local（PVE）--> 内容” 选项中将刚才下载的文件上传到 PVE 中。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p3.pstatp.com/large/pgc-image/5037ff045f554d9ea58826cdb35067f6)

2. 第二步请在 PVE 中新建一个 OMV 的虚拟机。注意 CD-ROM 那里选择加载刚才我们上传的 ISO 文件。还要注意在 “选项-- 引导顺序” 将 CD-ROM 启动调到第一位。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/0922ace76fed4da4b8d641de8f070abc)

3. 检查所有设置没有问题后，就可以启动虚拟机了，启动后在控制台我们可以看到下面的界面。选择第一项：Install 即可启动安装。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p3.pstatp.com/large/pgc-image/1ce339162a9544f6a99f748907c0fe8e)

4. 安装过程中，请选择英文安装，免得有错误发生，这里要输入你的主机名。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/5a09edcf31eb476f8606d33cdf8f31ab)

5. 域名默认 local 即可。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/064b989087cf402bb6d462a08f44b2a0)

6. 请注意，这里的镜像选择，请选择 china。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p9.pstatp.com/large/pgc-image/2746956e374042968ce7bfe943a3cfdd)

7. 镜像源，建议选择第二项，清华的镜像源。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/7c03c3f2145644ce90cdd821306b3655)

8. 若你虚拟机里建了多块磁盘，这里选择系统安装的磁盘。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/ed6b81785cb543f2837373ad133f24f0)

9. 一直等到系统安装完成，出现下面界面，将虚拟机中 CD-ROM 的 ISO 卸载，然后点击 continue 重启。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p1.pstatp.com/large/pgc-image/cc26e7026ce64d1aaacb888dd6ab00d1)

10、当出现如下界面，表示 OMV 安装完成。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p3.pstatp.com/large/pgc-image/0fba278e715942b7bfd20714a4cc136d)

11、你可以按照上图屏幕上的提示登录地址，通过浏览器进入后台管理界面了。此时可以选择中文，切换为中文界面。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p3.pstatp.com/large/pgc-image/91f960cdff684289a3881efcd23d498c)

12、进入后，请先在 “网络--接口” 中修改 OMV 的 IP 为静态 IP，然后指定我们预先设定好的 IP 地址。至此，我们的 OMV 就基本安装完成。

![“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装](http://p3.pstatp.com/large/pgc-image/53cd1017837546f6836c1fa3104e2363)

**注意事项：**

1. 注意虚拟机中的启动顺序，安装前将 CDROM 调整到第一项。
2. 镜像源选择清华，科大，网易，兰大，华为的都可以，但是经过我比较清华的似乎更稳定，更快一点点。
3. 本篇只是简单的将 OMV 安装好，里面的具体设置以后再详细介绍给大家。

---
**下一篇预告：**

# **“家庭云中心”建设（篇四）：Transmission 下载中心介绍及安装**
