title: 【随笔】OpenWrt 固件编译过程：本地编译
date: '2020-02-17 15:35:55'
updated: '2020-02-17 16:40:58'
tags: [openWRT]
permalink: /articles/2020/02/17/1581924955373.html
---
**OpenWrt 的编译可以分为两种方式：**

1. 本地的物理机/虚拟机/WSL（windows sub-linux）来执行编译工作。
2. 利用 GitHub 提供的 Action 功能，编写 continuous integration (CI) workflows 来实现在线云编译。

本篇先介绍一下本地编译的方法：

**第一步：依赖**

```
sudo apt-get install subversion g++ zlib1g-dev build-essential git python rsync man-db
sudo apt-get install libncurses5-dev gawk gettext unzip file libssl-dev wget zip time
```

**第二步：克隆**

源码可以使用官方的或是第三方维护的，当然你也可以用官方的源码加上一些你喜欢的 package 来组成自己的特有包来编译。

OpenWrt 官方：

```
Git clone https://github.com/openwrt/openwrt.git
```

或者第三方维护的：

```
Git clone https://github.com/coolsnowwolf/lede.git
```

由 GitHub 拉取代码要是没有代理的话速度会很慢，这里分享一个技巧：

> 你可以将仓库先由 GitHub 拉到国内的 “码云” 上，然后再由码云拉回本地，这样中转一下，速度就快多了
> 码云： https://gitee.com/

**第三步：更新**

> 在 Openwrt 系统中，“feed”是一系列的软件包，这些软件包需要通过一个统一的接口地址进行访问。
> “feed”软件包中的软件包可能分布在远程服务器上、在 SVN 上、在本地文件系统中或者其他的地方，
> 用户可以通过一种支持 feed 机制的协议，通过同一个地址进行访问。

在执行更新前，请记得修改 feeds.conf.default 文件里面的源路径。（当然要是你的网络连接国外的速度很快，请忽略）

这是我码云上的 openwrt feed 源列表：

```
src-git packages git@gitee.com:yfdoor/openwrt-packages.git
src-git luci git@gitee.com:yfdoor/openwrt-luci.git
src-git routing git@gitee.com:yfdoor/openwrt-routing.git
src-git telephony git@gitee.com:yfdoor/openwrt-telephony.git
```

然后执行：

```
./scripts/feeds update -a    // 更新
./scripts/feeds install -a   // 安装
```

**第四步：配置**

```
make defconfig               // 检查编译工具是否全，生成 .config 文件
make menuconfig              // 打开编译菜单，自定义项目，更新 .config 文件
```

**第五步：下载**

编译前最好先执行一下下载，当然你也可以跳过这步，直接编译。编译过程会自动执行下载。下载相关的工具包会放到 dl 文件夹。

```
make download V=s
```

**第六步：编译**

```
make V=99 or V=s   // V = verbose 全部都显示
```

**总结：**

OpenWRT 源码是由一堆 makefile 和补丁组成的，源代码中不包括任何的源代码或内核代码，使用脚本与 makefile 来定义需要下载哪些文件与打上补丁。因此一个好的可以科学上网的网络环境是很重要的。90% 编译失败都是网络的原因，请仔细查看失败后的报错信息来逐步 debug。

简言之，编译过程如下：

1. 下载交叉编译工具，内核头文件，C 库等。
2. 设置 staging_dir 目录，交叉编译的 toolchain 会安装到这里。
3. 创建 dl 目录， 所有的第三方源码包会被下载到这里
4. 创建 build_dir 目录， 用户态工具会被编译到这里
5. 创建 build_dir/target-arch/root 和 目标平台根文件系统
6. 在根文件系统中安装所有包，最后生成的镜象会在 bin/目录中

**注意事项：**

1. 网络，网络，可以翻墙的网络。
2. 若是使用 WSL 编译，请注意 openwrt 要求放的磁盘位置区分大小写。
   ```
   fsutil.exe file setCaseSensitiveInfo (path) enable //启用 NTFS 区分大小写功能
   ```
3. 若是使用 WSL 编译，在 windows 和 Linux 文件系统转移文件的时候请注意文件权限的问题。
4. 若是使用 WSL 编译，借用主机的 SSR 的时候，可以使用 proxychains 来实现。
5. 若编译过程中卡在某个文件的下载上，可关掉进程，手动将相应的文件下载到 dl 文件夹。

**附录：**

```
make clean     						#删除 bin build_dir
make dirclean  						#删除 bin build_dir staging_dir toolchain logs
make distclean 						#删除以上所有文件，dl 和 .config
make package/yfdoor/luci-adb-plus/compile V=s		#单独编译软件包 ake clean 
```
