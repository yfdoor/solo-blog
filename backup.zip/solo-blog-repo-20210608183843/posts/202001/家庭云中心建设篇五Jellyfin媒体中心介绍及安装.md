title: “家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装
date: '2020-01-29 17:19:48'
updated: '2020-02-05 20:28:54'
tags: [Jellyfin, 媒体中心]
permalink: /articles/2020/01/29/1580289587954.html
---
作为家庭云中心，那么媒体功能是必不可少的，甚至可以说是最主要的一个功能。那么要想实现媒体管理/视频解码，那么就需要一个小帮手来助我们一臂之力了。

作为这个领域的领头羊，大家可能用的比较多的是 Emby 或是 PLEX，但是随着时间的发展，这两个工具开始部分功能收费或是变成会员解锁功能，但是互联网最不缺乏的就是开源分享精神，此时一个新的工具出现在我们面前，他就是我们今天的主角：“Jellyfin”，下面是官方项目对这个软件的介绍：

> Jellyfin 是一个自由软件媒体系统，可让您控制媒体的管理和流媒体。它是专有的 Emby 和 Plex 的替代品，可通过多个应用程序从专用服务器向终端用户设备提供媒体。Jellyfin 是 Emby 3.5.2 版本的后代，移植到。NET Core 框架以支持完整的跨平台支持。没有任何附加条件，没有高级许可证或功能，也没有隐藏的议程：只是一个团队想要更好地构建更好的东西并共同努力实现它。我们欢迎任何有兴趣加入我们的人！
>
> 官网：https://jellyfin.media
>
> 项目：https://github.com/jellyfin/jellyfin

由于我们之前已经建立了 OMV NAS 系统，所以我们的 jellyfin 将建立在 OMV 系统之上。下面我们就开始今天的 Jellyfin 介绍：

1. 首先登录 OMV 的后台，在 OMV-Extras 中开启 Docker CE。

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p3.pstatp.com/large/pgc-image/4a35110bb3ed4977a2d1b49ae75af246)

2. 然后在插件中搜索 docker，安装 docker-GUI 插件，该插件会为你提供 docker 的界面管理。

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p9.pstatp.com/large/pgc-image/9d73ccc1c01348a19d674118eb810f12)

3. 安装成功后，你就可以在 OMV 的左侧管理面板“服务”中看到一个新的选项 “容器”。
4. 进入容器，在右上角搜索 “jellyfin”，找到 jellyfin/jellyfin, 并获取该镜像文件，等待下载完成。

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p9.pstatp.com/large/pgc-image/06aebfe7b69145caa1578f2bd0f540ce)

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p1.pstatp.com/large/pgc-image/a22df4f03d554c8eab5be17afdcc6e56)

5. 待下载完成后，部署该镜像。请注意以下设置：

* 端口转发：8096 端口
* 卷和挂载：
* /config （配置文件存储目录）
* /cache（cache 目录）
* /media（媒体文件目录）

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p1.pstatp.com/large/pgc-image/d75738a122c14639b699e77c4c057c0b)

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p1.pstatp.com/large/pgc-image/f2b28e8e3f09491f9fb542c0c9496ac0)

6. 设置完毕后，启动容器。随后即可通过 http://192.168.x.x:8096, 进入 jellyfin 管理界面。（http://192.168.x.x 是你的 OMV IP 地址）
7. 进入后台后按照提示进行简单的设置就可以进入 Jellyfin 了。在设置界面中添加对应的媒体库。

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p9.pstatp.com/large/pgc-image/a29a1063cba8493ca1839eaeee88bcd2)

8. 待媒体库设置完毕后，你就可以在主页看到你的媒体中心了。随后开始你的电影之旅吧！！

![“家庭云中心”建设（篇五）：Jellyfin 媒体中心介绍及安装](http://p9.pstatp.com/large/pgc-image/bac254361015419fad51cc8a54f50b53)

**注意事项：**

1. Jellyfin 挂载的卷文件夹注意文件夹权限。
2. 国家设置中没有 China，请选择 People's republic of china.
3. 添加媒体库的时候，元数据下载器，请不要选择 TheTVDB，因为该网站国内无法访问，若选上的话会影响元数据扫描速度。
4. 关于核显直通转码，后面单独讲。

---
**下一篇预告：**

# **“家庭云中心”建设（篇六）：建设你的个人主页--导航页**
