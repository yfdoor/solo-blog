title: 【随笔】Jellyfin IPTV 设置
date: '2021-06-05 19:32:49'
updated: '2021-06-05 19:33:31'
tags: [Jellyfin]
permalink: /articles/2021/06/05/1622892769837.html
---
IPTV source：https://iptv-org.github.io/iptv/countries/cn.m3u

XML 指南：http://epg.51zmt.top:8000/e.xml
