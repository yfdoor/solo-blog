title: “家庭云中心”建设（篇二）：openWRT 软路由介绍及安装
date: '2020-01-29 17:17:10'
updated: '2020-02-05 20:23:33'
tags: [openWRT, 路由]
permalink: /articles/2020/01/29/1580289430751.html
---
什么是软路由：

> 软路由是指利用台式机或服务器配合软件形成路由解决方案，主要靠软件的设置，达成路由器的功能；而硬路由则是以特有的硬设备，包括处理器、电源供应、嵌入式软件，提供设定的路由器功能。

什么是 openWRT：

> OpenWrt 可以被描述为一个嵌入式的 Linux 发行版。（主流路由器固件有 dd-wrt,tomato,openwrt 三类）对比一个单一的、静态的系统，OpenWrt 的包管理提供了一个完全可写的文件系统，从应用程序供应商提供的选择和配置，并允许您自定义的设备，以适应任何应用程序。
>
> 官网：https://openwrt.org/

我采用这个方案的主要目的是为了解决家中网络瓶颈的问题（旧路由不能跑满速），而且可以搭建当前流行的双线接入方案，并提升路由性能。

下面我们就来介绍一下如何在 PVE 上搭建 openWRT，并接入互联网。

1. 在安装 openWRT 之前，由于我还有其他的网络接口，因此首先需要在 PVE 的网络界面添加其他的接口。共有一个 WAN，两个 LAN。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/5961d8037cf640f0bbc1a7c53a9b2313)

2. 然后请在官网下载 openWRT 的镜像文件。在下载目录我们一般选择 combined-squashfs.img.gz 即可。下载后解压，镜像文件备用。关于官网上下载目录的文件区别请参考：

> **64**：用于现代 PC 硬件（大约在 2007 年以后的产品），它是为具有 64 位功能的计算机而构建的，并支持现代 CPU 功能。除非有充分的理由，否则请选择此选项。
> **Generic**：仅适用于 32 位硬件（旧硬件或某些 Atom 处理器），应为 i586 Linux 体系结构，将在 Pentium 4 及更高版本上运行。仅当您的硬件无法运行 64 位版本时才使用此功能。
> **Legacy**：用于奔腾 4 之前的非常旧的 PC 硬件，在 Linux 体系结构支持中称为 i386。它会错过许多现代硬件上想要/需要的功能，例如多核支持以及对超过 1GB RAM 的支持，但实际上会在较旧的硬件上运行，而其他版本则不会。
> **Geode**：是为 Geode SoC 定制的自定义旧版目标，Geode SoC 仍在许多（老化的）网络设备中使用，例如 PCEngines 的较旧 Alix 板
> Combined-squashfs.img.gz 该磁盘映像使用传统的 OpenWrt 布局，一个 squashfs 只读根文件系统和一个读写分区，在其中存储您安装的设置和软件包。由于此映像的组装方式，您只有 230 兆 MB 的空间来存储其他程序包和配置，而 Extroot 不起作用。
> Combined-ext4.img.gz 此磁盘映像使用单个读写 ext4 分区，没有只读 squashfs 根文件系统，因此可以扩大分区。故障安全模式或出厂重置等功能将不可用，因为它们需要只读的 squashfs 分区才能起作用。

3. PVE 中创建虚拟机，按照你的需求选择硬件属性即可。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/1e9fc6d0c8ea4484bd991f1ad22c83cd)

4. 将另外的网络接口添加进来。（这里也可以将网卡直通过来，后面单独讲直通）

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/6b545023402f4f7f9201be084b7e59c2)

5. 选择虚拟机已添加好的硬盘，点击分离，再将其删除。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/955bbb529ef446caba099c12c4d998e9)

6. 把下载好的镜像文件通过 SSH 上传到 PVE 服务器的目录，然后执行：

   ```
   qm importdisk 100 /home/data/openwrt.img local-lvm
   ```

   其中 100 代表的是虚拟机的编号， openwrt.img 即为你刚才上传的镜像文件。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/765aa185210f4905baca5c8ea4d3c882)

7. 执行后如下图，在虚拟机的硬件中会出现一个新的硬盘，这便是 opeWRT 的挂载盘了，此时你也可以调整该盘的大小。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/5499f9122e13475f8fe39d8097a13799)

8. 硬件准备完毕后，就可以启动虚拟机了，当你在控制台看到如下界面的时候，表示 openWRT 已经就绪了。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/ed7d0d94f918452cbc914b3ac8079527)

9. 在控制台，我们可以在 /etc/config 下的文件 network 中调整网络接口的 IP 以及其他设置，此时只建议修改 Lan 口为之前规划好的 IP 地址即可。其他可以以后通过控制台设定。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/78f88e14cf6a4b5ebd0ce98fa896bccf)

10、在网页上登录后台管理平台。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/341479c6b37a45bcaf9ae7ba9a54c89d)

11、首先我们需要先连接上外网，在 network/interface 下定义 WAN 口。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/d5fd6974b1ee4a0d82c56638cc1ceca4)

12、将光猫出来的网线接到 WAN 口上，将 WAN 口修改为 PPPOE 拨号模式，输入你的上网账号密码。保存应用，不出意外的话，此时你就可以连接外网了。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/d26586cb3a7b4eae9223fa474026194b)

13、接入外网后的第一步，我们先来把界面换成中文，在 software 中安装 luci-i18n-base-zh-cn 软件包，然后就可以将界面变为中文了。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/816e81b1e5284becac7d8c699ac24454)

14、重新进入 lan 口定义，可以同时将另外一个 Lan2 也绑定进来，而且同时设置 DHCP，让接入局域网的其他设备自动获取 IP。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/70f42fb1452e4688bf46b6bb68ecc48a)

15、最后将 PC 上之前设置的网络换回自动获取 IP。至此，openWRT 就部署完毕了。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p3.pstatp.com/large/pgc-image/36ba9a7386744147ba139d06d119ba3e)

16、让我们看一下网速的对比，由之前的不足百兆升到了 200 多兆，跑满了签约带宽。

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/1aed703b9f41418d8743d40cb85c4dfa)

![“家庭云中心”建设（篇二）：openWRT 软路由介绍及安装](http://p1.pstatp.com/large/pgc-image/039cc31127754315ba116746713dbed9)

**注意事项：**

1. openWRT 提供的是 img 镜像文件，不需要安装，直接挂载到虚拟机即可。
2. 网口，IP 定义请确保正确的对应关系。

---
**下一篇预告：**

# **“家庭云中心”建设（篇三）：Openmediavault（OMV）介绍及安装**
