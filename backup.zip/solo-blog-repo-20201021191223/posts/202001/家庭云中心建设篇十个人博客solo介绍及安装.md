title: “家庭云中心”建设（篇十）：个人博客 solo 介绍及安装
date: '2020-01-29 17:23:26'
updated: '2020-02-05 20:33:17'
tags: [博客, docker]
permalink: /articles/2020/01/29/1580289806500.html
---
作为一个爱折腾的人来说，不建一个自己的博客系统，似乎说不过去。而且是在你的家庭云中心已经搭建成功的情况下。用来记录生活的点滴，记录学习的笔记是再好不过了。

当前个人博客系统有很多 Typecho，wordpress，halo 等等，而一个偶然的机会，我在 GitHub 上看到一个叫做 solo 的个人博客系统，很小巧，而且和 GitHub 互动关联，可以将你的博客自动备份到 GitHub 上。

项目地址：https://github.com/88250/solo

项目主页的特点介绍：

> Solo 沉淀至今的**每一个功能你应该都会用到**。我们不会将只有“20%”用户使用的功能添加进来，只有这样才能保持博客系统本该有的纯净，足够轻量才能带来简约的使用体验。* Markdown / Emoji
>
> * 标签聚合分类
> * 自定义导航页面 / 链接
> * 随机文章 / 相关文章
> * 置顶 / 更新提醒
> * 自定义文章永久链接 / 签名档
> * 配置站点 SEO 参数 / 公告 / 页脚
> * 代码高亮 / 数学公式 / 流程图
> * 多皮肤，多端适配 / 社区皮肤
> * 多语言 / 国际化
> * 友情链接管理
> * 多用户写作，团队博客
> * Hexo / Jekyll / Markdown 导入
> * SQL / JSON / Markdown 导出
> * Atom / RSS / Sitemap
> * CDN 静态资源分离
> * 自动同步 GitHub 仓库
> * 内置 HTTPS+CDN 文件存储

这次，我将使用 docker 来安装 solo，看过我前面文章的人都知道，我使用的是 PVE+OMV 的方案，所以我会在 OMV 的 docker 中来建立 solo 程序。

第一步，由于 solo 需要数据库的支持，所以请首先打开 OMV 中 MySQL 插件。从左侧菜单中找到 MySQL，然后启用，记得设置数据库的密码。然后手动建一个数据库（库名 solo，字符集使用 utf8mb4，排序规则 utf8mb4_general_ci）

```
# 进入数据库 p后面跟你的密码
mysql -u root -p XXX
# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
```

![“家庭云中心”建设（篇十）：个人博客 solo 介绍及安装](http://p1.pstatp.com/large/pgc-image/740f0239a3774f708cca4f96498f4823)

第二步，在 docker 容器中搜索 b3log/solo，并将其下载下来。

![“家庭云中心”建设（篇十）：个人博客 solo 介绍及安装](http://p3.pstatp.com/large/pgc-image/8497cdfe56ac40b59a66aeba00bbe504)

第三步，SSH 登录到你 OMV 的后台，然后用如下命令来启动容器。

```
docker run --detach --name solo --network=host
--env RUNTIME_DB="MYSQL"
--env JDBC_USERNAME="omvadmin"
--env JDBC_PASSWORD="123456"
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver"
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC"
b3log/solo --listen_port=8080 --server_scheme=http --server_host=www.xxx.com --server_port=8303
```

* --env JDBC_USERNAME="omvadmin"，数据库默认用户为 omvadmin
* --env JDBC_PASSWORD="123456"， 将 123456 换成你的 MySQL 密码
* --listen_port=8080 监听的端口
* --server_scheme=http 请求方式，暂时使用 http 或改成 https
* --server_host=www.xxx.com 你的域名，如果你没有域名可以写 ip 地址，不要带端口
* --server_port：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可

第四步，进入后台网页，网址为你的 OMV IP + 8080 端口，例如：http://192.168.100.3:8080

![“家庭云中心”建设（篇十）：个人博客 solo 介绍及安装](http://p1.pstatp.com/large/pgc-image/09bbea1951fd4785b411d88b4ba90079)

第五步，至此你的博客系统基本搭建完成，然后登录你的 GitHub 账号就行了。记录下你的生活点滴吧。你所有的博客内容他会自动同步你的 GitHub "solo-blog" 项目下。

**注意事项：**

1. 该篇内容是在我们之前 Web 服务器搭建完成的基础上完成的，所以要是你的 nginx Web 服务没有搭建，你还需要先把 Web 服务搭建起来。
2. 该项目同时支持 H2 数据库，可以跳过 MySQL 的安装以及建库步骤，直接用如下命令设置 docker：

```
docker run
--detach
--name solo
--publish 8080:8080
--volume /sharedfolders/nas/docker/solo/h2:/opt/solo/h2
--env RUNTIME_DB="H2"
--env JDBC_USERNAME="root"
--env JDBC_PASSWORD="h2123456"
--env JDBC_DRIVER="org.h2.Driver"
--env JDBC_URL="jdbc:h2:/opt/solo/h2/db;MODE=MYSQL"
--restart unless-stopped
b3log/solo --listen_port=8080 --server_scheme=http --server_host=www.xxx.xyz --server_port=8303
```

* /sharedfolders/nas/docker/solo/h2 是挂载放置 H2 数据库的目录
* 其他的设置和上面 MySQL 设置类似。

---
**下一篇预告：**

# “家庭云中心”建设（篇十一）：同步工具 syncthing 介绍及安装
