title: “家庭云中心”建设（篇八）：NAS媒体中心影片自动下载字幕
date: '2020-01-29 17:21:48'
updated: '2020-02-05 20:31:01'
tags: [字幕, Jellyfin]
permalink: /articles/2020/01/29/1580289708184.html
---
有了媒体内容，当然不可缺少字幕的匹配。特别是喜欢直接下载“生肉”的朋友，拖回来的视频需要自己去匹配字幕文件。这个时候一个自动的字幕匹配工具就显得必不可少了。

第一种方法：我们之前安装过的 Jellyfin 自带的插件包含一个叫做 open subtitles 的插件，该插件可以帮助你自动去 open subtitles 网站匹配需要的字幕文件。

首先在插件选项里安装该插件，然后设置注册的用户名和密码。

![“家庭云中心”建设（篇八）：NAS媒体中心影片自动下载字幕](http://p3.pstatp.com/large/pgc-image/9eec3cd02d2349cc9509d753c061feec)

![“家庭云中心”建设（篇八）：NAS媒体中心影片自动下载字幕](http://p1.pstatp.com/large/pgc-image/5c5655ee8eb148f9b2a9996329b1db13)

设置成功后，去需要下载字幕文件的媒体库中，对字幕下载选项进行设置。

![“家庭云中心”建设（篇八）：NAS媒体中心影片自动下载字幕](http://p3.pstatp.com/large/pgc-image/e87553a614aa4aa9b6560e91afdf4f45)

该插件会定时执行来获取字幕文件，但是该方法的缺点是 open subtitles 网站收录的中文字幕不太全，有时候会匹配不到。

第二种方法：这时候我们的 GitHub 又该登场了。

> subfinder：是一个通用字幕查找器，可以查找字幕并下载。
> 项目地址：https://github.com/ausaki/subfinder

作者是国内的，所以里面的介绍都是中文的，安装和使用方法非常简单。这里简单引用一下：

安装：

* 如果你是 Linux 和 macOS 用户，由于系统自带 Python，推荐使用下面的方法安装 subfinder：pip install subfinder
* 安装完成之后，会在 Python 的 scripts 目录下添加一个叫做 subfinder 的可执行文件。

使用：

* 使用默认字幕查找器（shooter）查找单个视频的字幕：
* subfinder /path/to/videofile
* 使用默认字幕查找器（shooter）查找目录下（递归目录）所有视频的字幕：
* subfinder /path/to/directory_contains_video
* 使用指定的字幕查找器查找字幕，例如 zimuku：
* subfinder /path/to/directory_contains_video -m zimuku
* 同时使用多个字幕查找器查找字幕
* subfinder /path/to/directory_contains_video -m shooter zimuku
* 当指定多个字幕查找器时，subfinder 会依次尝试每个字幕查找器去查找字幕，只要有一个字幕查找器返回字幕信息，则不再使用后面的字幕查找器查找字幕。

脚本安装成功后，只需要在你的 OMV 上添加一个自动执行的任务就可以了，让系统定时执行你设置好的语句来更新字幕。（以 OMV 为例）

![“家庭云中心”建设（篇八）：NAS媒体中心影片自动下载字幕](http://p1.pstatp.com/large/pgc-image/bc60fb62d2b74a508c46f5cdfe58f406)

该方法由于可以直接在射手，字幕组，字幕库上搜索下载字幕文件，因此对国内用户来说更加的适合。

这样一来，你的自动字幕匹配工具就安装完成了。

**注意事项**：

1. NA。

---
**下一篇预告：**

# **“家庭云中心”建设（篇九）：可道云（kodexplorer）介绍及安装**
