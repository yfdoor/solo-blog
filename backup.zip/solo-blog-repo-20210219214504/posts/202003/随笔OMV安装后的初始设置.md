title: 【随笔】OMV 安装后的初始设置
date: '2020-03-28 21:13:31'
updated: '2020-03-30 21:30:55'
tags: [OMV]
permalink: /articles/2020/03/28/1585401211088.html
---
* 更换 Debian 源：
  ```
  cp /etc/apt/sources.list /etc/apt/sources.list.BK
  cat > /etc/apt/sources.list << EOF
  # 默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释

  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-updates main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-updates main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-backports main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian/ buster-backports main contrib non-free
  deb https://mirrors.tuna.tsinghua.edu.cn/debian-security buster/updates main contrib non-free
  # deb-src https://mirrors.tuna.tsinghua.edu.cn/debian-security buster/updates main contrib non-free

  EOF
  ```
* 更换 Docker 源：
  ```
  cat  >> /etc/docker/daemon.json << EOF
  {
    "registry-mirrors": ["https://zutp7vku.mirror.aliyuncs.com"]
  }
  EOF

  sudo systemctl daemon-reload
  sudo systemctl restart docker
  ```
* 安装 omv-extras：
  ```
  wget -O - https://github.com/OpenMediaVault-Plugin-Developers/packages/raw/master/install | bash
  ```
